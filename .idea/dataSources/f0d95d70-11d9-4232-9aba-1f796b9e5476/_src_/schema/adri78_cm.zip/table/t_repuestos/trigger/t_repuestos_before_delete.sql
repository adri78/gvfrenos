CREATE TRIGGER t_repuestos_before_delete
BEFORE DELETE ON t_repuestos
FOR EACH ROW
  BEGIN
 UPDATE  t_version 
  SET ver=(1+ver) 
  WHERE  idv='8';
END;
