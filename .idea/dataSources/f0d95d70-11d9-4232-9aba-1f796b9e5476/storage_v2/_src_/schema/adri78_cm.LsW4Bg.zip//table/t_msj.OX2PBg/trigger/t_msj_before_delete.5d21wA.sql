CREATE TRIGGER t_msj_before_delete
BEFORE DELETE ON t_msj
FOR EACH ROW
  BEGIN
 UPDATE  t_version 
  SET ver=(1+ver) 
  WHERE idv='9';
END;
